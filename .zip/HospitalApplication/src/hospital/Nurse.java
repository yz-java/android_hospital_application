package hospital;

public class Nurse {

}
