package hospital;

/**
 * A representation of BloodPressure measured in systolic and diastolic.
 * @author SeongMinJeong, JunaidPatel, EricCyr, JackYiu, YiChenZhu
 *
 */

public class BloodPressure {
	
	private int systolicBP;
	private int diastolicBP;
	
	/**
	 * Creates a new BloodPressure with the given systolicBP and diastolicBP.
	 * @param systolicBP
	 * @param diastolicBP
	 */
	public BloodPressure(Integer systolicBP, Integer diastolicBP) {
		this.systolicBP = systolicBP;
		this.diastolicBP = diastolicBP;
	}

	/**
	 * Returns systolicBP.
	 * @return systolicBP
	 */
	public Integer getSystolicBP() {
		return systolicBP;
	}

	/**
	 * Returns diastolicBP.
	 * @return diastolicBP
	 */
	public Integer getDiastolicBP() {
		return diastolicBP;
	}

	/**
	 * Returns a string representation of this BloodPressure
	 */
	public String toString() {
		String resultBP = systolicBP + ", " + diastolicBP;
		return resultBP;
	}
	
}
